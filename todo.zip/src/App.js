import "./App.css";
import { Input, DatePicker, Button, Checkbox } from "antd";
import { TodoItem } from "./components/TodoItem";
import { useSelector, useDispatch } from "react-redux";
import { useState } from "react";
import { add_todo } from "./store/actions";

// main component
function App() {
  // hooks
  const [text, setText] = useState("");
  const [date, setDate] = useState("");
  // store
  const todos = useSelector((state) => state.todos);
  const currentFilter = useSelector((state) => state.filter);
  const dispatch = useDispatch();
  function onChangeDate(date) {
    // console.log(date, dateString);
    setDate(date);
  }
  // onclick button Add
  const onAdd = () => {
    text && date && dispatch(add_todo(text, date));
  };

  return (
    <div className="App">
      <main>
        <h1>Todo List</h1>
        <div>
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="type smth ..."
            style={{ width: 350 }}
          />
          <DatePicker value={date} onChange={onChangeDate} />
          <Button onClick={onAdd} type="primary">
            Add
          </Button>
        </div>
        <div>
          {todos.map((el, id) => {
            return <TodoItem
              key={id} id={el.id} todo={el} />;
          })}
        </div>
      </main>
    </div>
  );
}
export default App;