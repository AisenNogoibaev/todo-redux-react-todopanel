import React from 'react'
import { Button, Checkbox } from 'antd'
import moment from 'moment'
import { useDispatch } from 'react-redux'
import { delete_todo, toggle_todo, edit_todo } from '../../store/actions'


export const TodoItem = ({ todo, id }) => {

    const dispatch = useDispatch()

    const deadline = moment(todo.deadline).format("MMM Do YY");

    return <div>
        <input
            style={{
                border: 'none',
                background: 'none',
                textDecoration:
                    todo.checked
                        ? 'line-through'
                        : 'none'
            }}
            type="text"
            value={todo.text}
            onChange={(e) => {
                dispatch(edit_todo(id, e.target.value))
            }} />

        <i style={{ textDecoration: todo.checked ? 'line-through' : 'none' }}>
            {deadline}
        </i>

        <div>
            <Checkbox
                checked={todo.checked}
                style={{ marginRight: 10 }}
                onChange={(e) => {
                    dispatch(toggle_todo(id, e.target.checked))
                }}></Checkbox>
            <Button
                onClick={() => {
                    dispatch(delete_todo(id))
                }}
                type="primary"
                danger>delete</Button>
        </div>
    </div>
}